#!/usr/bin/env python3
"""Fast, resumable batch OCR engine for voter-list PDFs and images.

The legacy app OCRs every voter card separately and may launch Tesseract dozens
of times per page. This engine OCRs a scanned page once, assigns OCR words to
card boxes by coordinates, and only retries a few failed cards. It also writes
one cache file per source document so large jobs can resume after interruption.
"""

from __future__ import annotations

import csv
import hashlib
import json
import multiprocessing
import os
import shutil
import sys
import tempfile
import time
from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable, Iterable, Iterator, Optional, Sequence

import cv2
import fitz  # PyMuPDF
import numpy as np
import pytesseract
import xlsxwriter
from PIL import Image, ImageOps, ImageSequence
from pytesseract import Output

from voter_ocr import (
    OCRConfig,
    VoterRecord,
    apply_review_flags,
    deduplicate_records,
    detect_card_boxes,
    parse_voter_record,
    preprocess_for_ocr,
    split_multi_record_text,
)

SUPPORTED_SUFFIXES = {".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff"}
ProgressCallback = Callable[[int, int, str], None]


@dataclass
class BatchConfig:
    dpi: int = 180
    language: str = "hin+eng"
    page_psm: int = 11
    min_confidence: float = 35.0
    detect_cards: bool = True
    skip_first_pages: int = 0
    max_pages: Optional[int] = None
    workers: int = 2
    recursive: bool = True
    resume: bool = True
    ocr_timeout_seconds: int = 90
    fallback_cards_per_page: int = 3
    rows_per_workbook: int = 250_000
    write_csv: bool = True


@dataclass
class FileResult:
    source: str
    cache_file: str
    meta_file: str
    rows: int
    review_rows: int
    pages: int
    elapsed_seconds: float
    status: str
    error: str = ""


@dataclass
class BatchResult:
    output_dir: str
    files_total: int
    files_completed: int
    files_skipped: int
    files_failed: int
    rows: int
    review_rows: int
    pages: int
    excel_files: list[str]
    csv_file: str
    failures_file: str
    cancelled: bool = False


class BatchCancelled(RuntimeError):
    pass


def configure_tesseract() -> tuple[bool, str]:
    """Find Tesseract automatically, including common Windows installs."""
    candidates: list[Path] = []
    env_cmd = os.environ.get("TESSERACT_CMD", "").strip()
    if env_cmd:
        candidates.append(Path(env_cmd))

    found = shutil.which("tesseract")
    if found:
        candidates.append(Path(found))

    if os.name == "nt":
        roots = [
            os.environ.get("ProgramFiles"),
            os.environ.get("ProgramFiles(x86)"),
            os.environ.get("LOCALAPPDATA"),
        ]
        for root in filter(None, roots):
            candidates.extend(
                [
                    Path(root) / "Tesseract-OCR" / "tesseract.exe",
                    Path(root) / "Programs" / "Tesseract-OCR" / "tesseract.exe",
                ]
            )
        candidates.append(Path(r"C:\Program Files\Tesseract-OCR\tesseract.exe"))

    seen: set[str] = set()
    for candidate in candidates:
        key = str(candidate).lower()
        if key in seen:
            continue
        seen.add(key)
        if candidate.is_file():
            pytesseract.pytesseract.tesseract_cmd = str(candidate)
            os.environ["PATH"] = str(candidate.parent) + os.pathsep + os.environ.get("PATH", "")
            return True, str(candidate)
    return False, "Tesseract OCR was not found. Install Tesseract OCR, then reopen the app."


def verify_tesseract_languages(language: str) -> tuple[bool, str]:
    ok, message = configure_tesseract()
    if not ok:
        return False, message
    try:
        available = set(pytesseract.get_languages(config=""))
    except Exception as exc:
        return False, f"Tesseract was found but could not be queried: {exc}"
    requested = {part.strip() for part in language.split("+") if part.strip()}
    missing = sorted(requested - available)
    if missing:
        return False, f"Missing Tesseract language pack(s): {', '.join(missing)}"
    return True, message


def discover_files(input_path: Path, recursive: bool = True) -> list[Path]:
    input_path = input_path.expanduser().resolve()
    if input_path.is_file():
        return [input_path] if input_path.suffix.lower() in SUPPORTED_SUFFIXES else []
    if not input_path.is_dir():
        return []
    iterator = input_path.rglob("*") if recursive else input_path.glob("*")
    return sorted(
        (p for p in iterator if p.is_file() and p.suffix.lower() in SUPPORTED_SUFFIXES),
        key=lambda p: str(p).lower(),
    )


def _source_signature(path: Path) -> dict[str, object]:
    stat = path.stat()
    return {
        "path": str(path.resolve()),
        "size": stat.st_size,
        "mtime_ns": stat.st_mtime_ns,
    }


def _cache_key(path: Path) -> str:
    return hashlib.sha1(str(path.resolve()).encode("utf-8", errors="replace")).hexdigest()


def _cache_paths(path: Path, cache_dir: Path) -> tuple[Path, Path]:
    key = _cache_key(path)
    return cache_dir / f"{key}.jsonl", cache_dir / f"{key}.meta.json"


def _load_meta(meta_file: Path) -> dict[str, object]:
    try:
        return json.loads(meta_file.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}


def _cache_is_valid(path: Path, cache_file: Path, meta_file: Path) -> bool:
    if not cache_file.is_file() or not meta_file.is_file():
        return False
    meta = _load_meta(meta_file)
    return meta.get("status") == "success" and meta.get("signature") == _source_signature(path)


def _check_stop(stop_file: Optional[str]) -> None:
    if stop_file and Path(stop_file).exists():
        raise BatchCancelled("Batch stopped by user")


def _ocr_words(image: Image.Image, config: BatchConfig, psm: Optional[int] = None) -> list[dict[str, object]]:
    prepared = preprocess_for_ocr(image)
    data = pytesseract.image_to_data(
        prepared,
        lang=config.language,
        config=f"--oem 3 --psm {psm or config.page_psm}",
        output_type=Output.DICT,
        timeout=max(5, int(config.ocr_timeout_seconds)),
    )
    words: list[dict[str, object]] = []
    count = len(data.get("text", []))
    for idx in range(count):
        text = str(data["text"][idx]).strip()
        if not text:
            continue
        try:
            conf = float(data["conf"][idx])
        except (TypeError, ValueError):
            conf = -1.0
        words.append(
            {
                "text": text,
                "conf": conf,
                "left": int(data["left"][idx]),
                "top": int(data["top"][idx]),
                "width": int(data["width"][idx]),
                "height": int(data["height"][idx]),
                "block": int(data["block_num"][idx]),
                "par": int(data["par_num"][idx]),
                "line": int(data["line_num"][idx]),
            }
        )
    return words


def _words_to_text(words: Sequence[dict[str, object]]) -> tuple[str, float]:
    if not words:
        return "", 0.0
    grouped: dict[tuple[int, int, int], list[dict[str, object]]] = {}
    for word in words:
        key = (int(word["block"]), int(word["par"]), int(word["line"]))
        grouped.setdefault(key, []).append(word)
    lines: list[tuple[int, int, str]] = []
    for line_words in grouped.values():
        ordered = sorted(line_words, key=lambda w: int(w["left"]))
        text = " ".join(str(w["text"]) for w in ordered).strip()
        if text:
            lines.append((min(int(w["top"]) for w in ordered), min(int(w["left"]) for w in ordered), text))
    lines.sort(key=lambda item: (item[0], item[1]))
    valid_conf = [float(w["conf"]) for w in words if float(w["conf"]) >= 0]
    confidence = float(np.mean(valid_conf)) if valid_conf else 0.0
    return "\n".join(item[2] for item in lines), confidence


def _words_in_box(words: Sequence[dict[str, object]], box: tuple[int, int, int, int]) -> list[dict[str, object]]:
    x, y, w, h = box
    x2, y2 = x + w, y + h
    output: list[dict[str, object]] = []
    for word in words:
        cx = int(word["left"]) + int(word["width"]) / 2
        cy = int(word["top"]) + int(word["height"]) / 2
        if x <= cx <= x2 and y <= cy <= y2:
            output.append(word)
    return output


def _words_in_column(words: Sequence[dict[str, object]], width: int, column: int) -> list[dict[str, object]]:
    left = width * column / 3
    right = width * (column + 1) / 3
    return [
        word
        for word in words
        if left <= int(word["left"]) + int(word["width"]) / 2 < right
    ]


def _record_needs_retry(record: VoterRecord) -> bool:
    return (not record.epic_id and not record.voter_name) or record.ocr_confidence < 18.0


def _ocr_one_crop(
    crop: Image.Image,
    config: BatchConfig,
    source_file: str,
    page_number: int,
    card_number: int,
) -> VoterRecord:
    words = _ocr_words(crop, config, psm=6)
    text, confidence = _words_to_text(words)
    return parse_voter_record(
        text,
        confidence,
        source_file,
        page_number,
        card_number,
        config.min_confidence,
    )


def _parse_native_blocks(
    page: fitz.Page,
    source_file: str,
    page_number: int,
    config: BatchConfig,
) -> list[VoterRecord]:
    texts: list[str] = []
    for block in page.get_text("blocks"):
        text = str(block[4]).strip()
        if len(text) >= 12:
            texts.append(text)
    if not texts:
        return []

    candidates: list[str] = []
    for text in texts:
        parts = split_multi_record_text(text)
        candidates.extend(parts if parts else [text])

    records: list[VoterRecord] = []
    for idx, text in enumerate(candidates, start=1):
        record = parse_voter_record(text, 100.0, source_file, page_number, idx, config.min_confidence)
        if record.epic_id or record.voter_name or record.age:
            records.append(record)
    # Native extraction is accepted only when it looks like multiple voter rows.
    return records if len(records) >= 4 else []


def _process_scanned_page(
    image: Image.Image,
    source_file: str,
    page_number: int,
    config: BatchConfig,
) -> list[VoterRecord]:
    legacy_config = OCRConfig(
        dpi=config.dpi,
        language=config.language,
        psm=6,
        min_confidence=config.min_confidence,
        detect_cards=config.detect_cards,
        skip_first_pages=config.skip_first_pages,
        max_pages=config.max_pages,
    )
    boxes = detect_card_boxes(image, legacy_config) if config.detect_cards else []
    words = _ocr_words(image, config, psm=config.page_psm)
    records: list[VoterRecord] = []

    if len(boxes) >= legacy_config.min_card_count:
        retry_indexes: list[int] = []
        for card_number, box in enumerate(boxes, start=1):
            text, confidence = _words_to_text(_words_in_box(words, box))
            record = parse_voter_record(
                text,
                confidence,
                source_file,
                page_number,
                card_number,
                config.min_confidence,
            )
            records.append(record)
            if _record_needs_retry(record):
                retry_indexes.append(card_number - 1)

        # Retry only a small number of failed cards, preventing one page from
        # starting 30-90 separate Tesseract processes.
        for idx in retry_indexes[: max(0, config.fallback_cards_per_page)]:
            x, y, w, h = boxes[idx]
            crop = image.crop((x, y, x + w, y + h))
            retried = _ocr_one_crop(crop, config, source_file, page_number, idx + 1)
            old = records[idx]
            old_score = bool(old.epic_id) + bool(old.voter_name) + bool(old.age) + bool(old.gender)
            new_score = bool(retried.epic_id) + bool(retried.voter_name) + bool(retried.age) + bool(retried.gender)
            if new_score > old_score or retried.ocr_confidence > old.ocr_confidence + 8:
                records[idx] = retried
    else:
        # No reliable borders: split the single page OCR result into three page
        # columns, then split each column into voter chunks.
        card_number = 0
        for column in range(3):
            text, confidence = _words_to_text(_words_in_column(words, image.width, column))
            chunks = split_multi_record_text(text)
            if not chunks and text:
                chunks = [text]
            for chunk in chunks:
                card_number += 1
                records.append(
                    parse_voter_record(
                        chunk,
                        confidence,
                        source_file,
                        page_number,
                        card_number,
                        config.min_confidence,
                    )
                )

    filtered = [
        record
        for record in records
        if record.epic_id or record.voter_name or record.age or len(record.raw_ocr_text) >= 12
    ]
    return filtered


def _iter_image_frames(path: Path, config: BatchConfig) -> tuple[int, Iterator[tuple[int, Image.Image]]]:
    image = Image.open(path)
    total = getattr(image, "n_frames", 1)
    start = min(max(config.skip_first_pages, 0), total)
    stop = total if config.max_pages is None else min(total, start + max(0, config.max_pages))

    def generator() -> Iterator[tuple[int, Image.Image]]:
        try:
            for index in range(start, stop):
                image.seek(index)
                yield index + 1, ImageOps.exif_transpose(image.copy()).convert("RGB")
        finally:
            image.close()

    return max(0, stop - start), generator()


def process_file_fast(
    path: Path,
    config: BatchConfig,
    stop_file: Optional[str] = None,
) -> tuple[list[VoterRecord], int]:
    source_file = path.name
    records: list[VoterRecord] = []
    pages_processed = 0

    if path.suffix.lower() == ".pdf":
        doc = fitz.open(path)
        try:
            start = min(max(config.skip_first_pages, 0), len(doc))
            stop = len(doc) if config.max_pages is None else min(len(doc), start + max(0, config.max_pages))
            matrix = fitz.Matrix(config.dpi / 72.0, config.dpi / 72.0)
            for index in range(start, stop):
                _check_stop(stop_file)
                page = doc[index]
                page_number = index + 1
                native_records = _parse_native_blocks(page, source_file, page_number, config)
                if native_records:
                    page_records = native_records
                else:
                    pix = page.get_pixmap(matrix=matrix, alpha=False)
                    image = Image.frombytes("RGB", (pix.width, pix.height), pix.samples)
                    page_records = _process_scanned_page(image, source_file, page_number, config)
                    image.close()
                records.extend(page_records)
                pages_processed += 1
        finally:
            doc.close()
    else:
        _total, frames = _iter_image_frames(path, config)
        for page_number, image in frames:
            _check_stop(stop_file)
            records.extend(_process_scanned_page(image, source_file, page_number, config))
            image.close()
            pages_processed += 1

    return deduplicate_records(records), pages_processed


def _write_jsonl(records: Sequence[VoterRecord], output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    temp = output.with_suffix(output.suffix + f".tmp.{os.getpid()}")
    with temp.open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(json.dumps(asdict(record), ensure_ascii=False) + "\n")
    os.replace(temp, output)


def _worker(job: dict[str, object]) -> FileResult:
    path = Path(str(job["path"]))
    config = BatchConfig(**dict(job["config"]))
    cache_file = Path(str(job["cache_file"]))
    meta_file = Path(str(job["meta_file"]))
    stop_file = str(job.get("stop_file") or "") or None
    started = time.perf_counter()
    ok, message = verify_tesseract_languages(config.language)
    if not ok:
        raise RuntimeError(message)

    try:
        records, pages = process_file_fast(path, config, stop_file=stop_file)
        _write_jsonl(records, cache_file)
        review_rows = sum(1 for record in records if record.review_needed)
        result = FileResult(
            source=str(path),
            cache_file=str(cache_file),
            meta_file=str(meta_file),
            rows=len(records),
            review_rows=review_rows,
            pages=pages,
            elapsed_seconds=round(time.perf_counter() - started, 2),
            status="success",
        )
    except BatchCancelled as exc:
        result = FileResult(
            source=str(path), cache_file=str(cache_file), meta_file=str(meta_file), rows=0,
            review_rows=0, pages=0, elapsed_seconds=round(time.perf_counter() - started, 2),
            status="cancelled", error=str(exc),
        )
    except Exception as exc:
        result = FileResult(
            source=str(path), cache_file=str(cache_file), meta_file=str(meta_file), rows=0,
            review_rows=0, pages=0, elapsed_seconds=round(time.perf_counter() - started, 2),
            status="failed", error=f"{type(exc).__name__}: {exc}",
        )

    meta = asdict(result)
    meta["signature"] = _source_signature(path)
    meta_file.parent.mkdir(parents=True, exist_ok=True)
    temp_meta = meta_file.with_suffix(meta_file.suffix + f".tmp.{os.getpid()}")
    temp_meta.write_text(json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8")
    os.replace(temp_meta, meta_file)
    return result


COLUMNS = [
    ("Source File", "source_file", 24),
    ("Page", "page_number", 8),
    ("Card", "card_number", 8),
    ("Serial Number", "serial_number", 13),
    ("EPIC ID", "epic_id", 15),
    ("Voter Name", "voter_name", 24),
    ("Relative Name", "relative_name", 24),
    ("Relation Type", "relation_type", 17),
    ("House Number", "house_number", 16),
    ("Age", "age", 8),
    ("Gender", "gender", 18),
    ("OCR Confidence", "ocr_confidence", 15),
    ("Review Needed", "review_needed", 14),
    ("Review Issues", "review_issues", 32),
    ("Raw OCR Text", "raw_ocr_text", 55),
]


def _iter_cached_records(cache_files: Sequence[Path]) -> Iterator[dict[str, object]]:
    for cache_file in cache_files:
        try:
            with cache_file.open("r", encoding="utf-8") as handle:
                for line in handle:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        yield json.loads(line)
                    except json.JSONDecodeError:
                        continue
        except OSError:
            continue


def _new_workbook(path: Path) -> tuple[xlsxwriter.Workbook, object, object, dict[str, object]]:
    workbook = xlsxwriter.Workbook(str(path), {"constant_memory": True})
    header_fmt = workbook.add_format(
        {"bold": True, "font_color": "#FFFFFF", "bg_color": "#1F4E78", "border": 1, "align": "center"}
    )
    text_fmt = workbook.add_format({"valign": "top", "border": 1})
    wrap_fmt = workbook.add_format({"valign": "top", "border": 1, "text_wrap": True})
    number_fmt = workbook.add_format({"valign": "top", "border": 1, "align": "center"})
    voters = workbook.add_worksheet("Voters")
    review = workbook.add_worksheet("Review Required")
    for sheet in (voters, review):
        sheet.freeze_panes(1, 0)
        sheet.set_row(0, 24)
        for col, (title, _field, width) in enumerate(COLUMNS):
            sheet.write(0, col, title, header_fmt)
            sheet.set_column(col, col, width)
    return workbook, voters, review, {"text": text_fmt, "wrap": wrap_fmt, "number": number_fmt}


def _write_excel_record(sheet: object, row: int, data: dict[str, object], formats: dict[str, object]) -> None:
    for col, (_title, field, _width) in enumerate(COLUMNS):
        value = data.get(field, "")
        if isinstance(value, bool):
            value = "Yes" if value else "No"
        if field in {"review_issues", "raw_ocr_text"}:
            fmt = formats["wrap"]
        elif field in {"page_number", "card_number", "age", "ocr_confidence"}:
            fmt = formats["number"]
        else:
            fmt = formats["text"]
        sheet.write(row, col, value, fmt)


def build_outputs(
    cache_files: Sequence[Path],
    output_dir: Path,
    config: BatchConfig,
    file_results: Sequence[FileResult],
) -> tuple[list[str], str, str, int, int]:
    output_dir.mkdir(parents=True, exist_ok=True)
    excel_files: list[str] = []
    csv_path = output_dir / "voters_all.csv"
    review_csv_path = output_dir / "review_required.csv"
    failures_path = output_dir / "failed_files.csv"

    csv_handle = None
    review_handle = None
    csv_writer = None
    review_writer = None
    if config.write_csv:
        csv_handle = csv_path.open("w", encoding="utf-8-sig", newline="")
        review_handle = review_csv_path.open("w", encoding="utf-8-sig", newline="")
        fieldnames = [field for _title, field, _width in COLUMNS]
        csv_writer = csv.DictWriter(csv_handle, fieldnames=fieldnames)
        review_writer = csv.DictWriter(review_handle, fieldnames=fieldnames)
        csv_writer.writeheader()
        review_writer.writeheader()

    part = 0
    voters_row = 0
    review_row = 0
    workbook = voters = review = formats = None
    total_rows = 0
    total_review = 0

    def open_part() -> None:
        nonlocal part, voters_row, review_row, workbook, voters, review, formats
        part += 1
        part_path = output_dir / f"voter_results_{part:03d}.xlsx"
        workbook, voters, review, formats = _new_workbook(part_path)
        excel_files.append(str(part_path))
        voters_row = 1
        review_row = 1

    open_part()
    try:
        for data in _iter_cached_records(cache_files):
            if voters_row > max(1, min(config.rows_per_workbook, 1_000_000)):
                assert workbook is not None
                workbook.close()
                open_part()
            assert voters is not None and review is not None and formats is not None
            _write_excel_record(voters, voters_row, data, formats)
            voters_row += 1
            total_rows += 1
            if bool(data.get("review_needed")):
                _write_excel_record(review, review_row, data, formats)
                review_row += 1
                total_review += 1
            if csv_writer is not None:
                row = {field: data.get(field, "") for _title, field, _width in COLUMNS}
                csv_writer.writerow(row)
                if bool(data.get("review_needed")) and review_writer is not None:
                    review_writer.writerow(row)
    finally:
        if workbook is not None:
            workbook.close()
        if csv_handle is not None:
            csv_handle.close()
        if review_handle is not None:
            review_handle.close()

    with failures_path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=["source", "status", "error", "elapsed_seconds"])
        writer.writeheader()
        for result in file_results:
            if result.status != "success":
                writer.writerow(
                    {
                        "source": result.source,
                        "status": result.status,
                        "error": result.error,
                        "elapsed_seconds": result.elapsed_seconds,
                    }
                )

    summary_path = output_dir / "batch_summary.json"
    summary_path.write_text(
        json.dumps(
            {
                "generated_at": time.strftime("%Y-%m-%d %H:%M:%S"),
                "rows": total_rows,
                "review_rows": total_review,
                "files": [asdict(item) for item in file_results],
                "settings": asdict(config),
                "excel_files": excel_files,
                "csv_file": str(csv_path) if config.write_csv else "",
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    return excel_files, str(csv_path) if config.write_csv else "", str(failures_path), total_rows, total_review


def run_batch(
    files: Sequence[Path],
    output_dir: Path,
    config: Optional[BatchConfig] = None,
    progress_callback: Optional[ProgressCallback] = None,
) -> BatchResult:
    config = config or BatchConfig()
    output_dir = output_dir.expanduser().resolve()
    cache_dir = output_dir / ".voter_ocr_cache"
    cache_dir.mkdir(parents=True, exist_ok=True)
    stop_file = output_dir / ".stop_voter_ocr"
    try:
        stop_file.unlink()
    except FileNotFoundError:
        pass

    ok, message = verify_tesseract_languages(config.language)
    if not ok:
        raise RuntimeError(message)

    unique_files = []
    seen: set[str] = set()
    for item in files:
        path = Path(item).expanduser().resolve()
        key = str(path).lower()
        if key not in seen and path.is_file() and path.suffix.lower() in SUPPORTED_SUFFIXES:
            unique_files.append(path)
            seen.add(key)

    total = len(unique_files)
    if total == 0:
        raise ValueError("No supported PDF or image files were found.")

    results: list[FileResult] = []
    cache_files: list[Path] = []
    skipped = 0
    pending_jobs: list[dict[str, object]] = []
    for path in unique_files:
        cache_file, meta_file = _cache_paths(path, cache_dir)
        if config.resume and _cache_is_valid(path, cache_file, meta_file):
            meta = _load_meta(meta_file)
            result = FileResult(
                source=str(path),
                cache_file=str(cache_file),
                meta_file=str(meta_file),
                rows=int(meta.get("rows", 0)),
                review_rows=int(meta.get("review_rows", 0)),
                pages=int(meta.get("pages", 0)),
                elapsed_seconds=float(meta.get("elapsed_seconds", 0.0)),
                status="success",
            )
            results.append(result)
            cache_files.append(cache_file)
            skipped += 1
        else:
            pending_jobs.append(
                {
                    "path": str(path),
                    "config": asdict(config),
                    "cache_file": str(cache_file),
                    "meta_file": str(meta_file),
                    "stop_file": str(stop_file),
                }
            )

    completed = skipped
    if progress_callback:
        progress_callback(completed, total, f"Found {total} file(s); {skipped} already completed")

    cancelled = False
    workers = max(1, min(int(config.workers), 8, os.cpu_count() or 1))
    if pending_jobs:
        with ProcessPoolExecutor(max_workers=workers, mp_context=multiprocessing.get_context("spawn")) as executor:
            future_map = {executor.submit(_worker, job): job for job in pending_jobs}
            while future_map:
                if stop_file.exists():
                    cancelled = True
                    for future in future_map:
                        future.cancel()
                done, _not_done = wait(future_map, timeout=0.25, return_when=FIRST_COMPLETED)
                if not done:
                    continue
                for future in done:
                    job = future_map.pop(future)
                    try:
                        result = future.result()
                    except Exception as exc:
                        result = FileResult(
                            source=str(job["path"]), cache_file=str(job["cache_file"]), meta_file=str(job["meta_file"]),
                            rows=0, review_rows=0, pages=0, elapsed_seconds=0.0,
                            status="failed", error=f"{type(exc).__name__}: {exc}",
                        )
                    results.append(result)
                    if result.status == "success":
                        cache_files.append(Path(result.cache_file))
                    if result.status == "cancelled":
                        cancelled = True
                    completed += 1
                    if progress_callback:
                        name = Path(result.source).name
                        progress_callback(completed, total, f"{result.status.title()}: {name} ({result.rows} row(s))")

    if cancelled:
        failed = sum(1 for item in results if item.status == "failed")
        return BatchResult(
            output_dir=str(output_dir), files_total=total, files_completed=sum(1 for x in results if x.status == "success"),
            files_skipped=skipped, files_failed=failed, rows=sum(x.rows for x in results),
            review_rows=sum(x.review_rows for x in results), pages=sum(x.pages for x in results),
            excel_files=[], csv_file="", failures_file="", cancelled=True,
        )

    if progress_callback:
        progress_callback(total, total, "Creating CSV and Excel output files...")
    excel_files, csv_file, failures_file, rows, review_rows = build_outputs(cache_files, output_dir, config, results)
    failed = sum(1 for item in results if item.status == "failed")
    return BatchResult(
        output_dir=str(output_dir),
        files_total=total,
        files_completed=sum(1 for item in results if item.status == "success"),
        files_skipped=skipped,
        files_failed=failed,
        rows=rows,
        review_rows=review_rows,
        pages=sum(item.pages for item in results),
        excel_files=excel_files,
        csv_file=csv_file,
        failures_file=failures_file,
        cancelled=False,
    )


def request_stop(output_dir: Path) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    (output_dir / ".stop_voter_ocr").write_text("stop", encoding="utf-8")


def default_workers() -> int:
    count = os.cpu_count() or 2
    return max(1, min(4, count // 2 or 1))
