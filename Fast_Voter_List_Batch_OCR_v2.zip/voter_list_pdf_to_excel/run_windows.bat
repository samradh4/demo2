@echo off
setlocal
cd /d "%~dp0"
if not exist .venv\Scripts\python.exe (
  call setup_windows.bat
  exit /b %errorlevel%
)
.venv\Scripts\python.exe batch_gui.py
if errorlevel 1 pause
endlocal
