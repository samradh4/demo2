# Fast Voter List PDF To Excel — Folder Batch OCR

This version is designed for large folders rather than manually adding one PDF at a time.

## What changed

- Select an entire folder of PDFs/images in one click.
- Process multiple files in parallel.
- OCR a scanned page once and assign words to voter-card boxes by coordinates.
- Retry only a few failed cards instead of OCRing every card twice.
- Extract native PDF text directly when it is available.
- Save one cache file per completed document.
- Resume after shutdown, crash, or manual stop.
- Skip completed files automatically.
- Split large Excel output into multiple workbooks.
- Produce CSV output and a failed-files report.
- Detect the normal Windows Tesseract installation automatically.

## Windows

1. Extract the ZIP.
2. Double-click `setup_windows.bat` once.
3. Later, open the app with `run_windows.bat`.
4. Choose the input folder and output folder.
5. Keep **Fast** mode and **Resume completed files** enabled.
6. Click **Start One-Click Batch**.

The old single-file interface remains available through `run_legacy_windows.bat`.

## macOS

```bash
chmod +x setup_mac.sh run_mac.sh Voter_OCR_Mac.command
./setup_mac.sh
```

Later:

```bash
./run_mac.sh
```

## Recommended settings for 3,000 files

- Mode: **Fast**
- Workers: **2** initially; 3–4 on a stronger CPU
- Include subfolders: enabled
- Resume completed files: enabled
- Also create CSV: enabled

More workers are not always faster because each Tesseract process also uses CPU and memory.

## Outputs

- `voter_results_001.xlsx`, `voter_results_002.xlsx`, ...
- `voters_all.csv`
- `review_required.csv`
- `failed_files.csv`
- `batch_summary.json`
- `.voter_ocr_cache/` — resume data; do not delete until the job is complete

## Command line

```bash
python batch_cli.py "C:\path\to\pdf_folder" "C:\path\to\output_folder" --workers 2 --dpi 160
```

Run the same command again to resume completed files.

## Accuracy and speed

Scanned voter rolls still require real OCR and cannot convert instantly on one ordinary computer. Speed depends on page count, scan quality, CPU, and layout. The main improvement is reducing Tesseract launches from potentially dozens per page to normally one per page.

Always verify rows in the review output against the original voter list.
