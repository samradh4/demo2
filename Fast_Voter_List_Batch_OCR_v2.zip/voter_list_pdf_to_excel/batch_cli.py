#!/usr/bin/env python3
"""Command-line launcher for fast resumable folder batch OCR."""

from __future__ import annotations

import argparse
from pathlib import Path

from fast_batch_ocr import BatchConfig, default_workers, discover_files, run_batch


def main() -> int:
    parser = argparse.ArgumentParser(description="Fast resumable folder batch voter-list OCR")
    parser.add_argument("input", help="Input folder or one PDF/image")
    parser.add_argument("output", help="Output folder")
    parser.add_argument("--workers", type=int, default=default_workers())
    parser.add_argument("--dpi", type=int, default=160)
    parser.add_argument("--skip-first-pages", type=int, default=0)
    parser.add_argument("--max-pages", type=int, default=None)
    parser.add_argument("--no-resume", action="store_true")
    parser.add_argument("--no-recursive", action="store_true")
    args = parser.parse_args()

    source = Path(args.input)
    files = discover_files(source, recursive=not args.no_recursive)
    config = BatchConfig(
        dpi=args.dpi,
        workers=args.workers,
        skip_first_pages=args.skip_first_pages,
        max_pages=args.max_pages,
        recursive=not args.no_recursive,
        resume=not args.no_resume,
    )

    def progress(done: int, total: int, message: str) -> None:
        print(f"[{done}/{total}] {message}", flush=True)

    result = run_batch(files, Path(args.output), config, progress)
    if result.cancelled:
        print("Stopped safely. Run the same command again to resume.")
        return 2
    print(f"Finished. Rows: {result.rows}; failed files: {result.files_failed}")
    print(f"Output folder: {result.output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
