import shutil
import tempfile
import unittest
import zipfile
from pathlib import Path

import fitz

from fast_batch_ocr import BatchConfig, discover_files, run_batch


class FastBatchTests(unittest.TestCase):
    def _make_native_pdf(self, path: Path, file_index: int) -> None:
        doc = fitz.open()
        page = doc.new_page(width=595, height=842)
        y = 40
        for i in range(5):
            text = (
                f"{i + 1} ABC{file_index}{i:06d}\n"
                f"Name: Person {file_index}-{i}\n"
                f"Father Name: Parent {i}\n"
                f"House No: {10 + i}\n"
                f"Age: {20 + i} Gender: Male"
            )
            page.insert_textbox(fitz.Rect(40, y, 300, y + 90), text, fontsize=10)
            y += 140
        doc.save(path)
        doc.close()

    def test_discover_and_resume_native_pdfs(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            source = root / "input"
            output = root / "output"
            source.mkdir()
            self._make_native_pdf(source / "a.pdf", 1)
            self._make_native_pdf(source / "b.pdf", 2)
            files = discover_files(source)
            self.assertEqual(len(files), 2)

            config = BatchConfig(workers=1, language="eng", write_csv=True, rows_per_workbook=100)
            first = run_batch(files, output, config)
            self.assertEqual(first.files_failed, 0)
            self.assertEqual(first.rows, 10)
            self.assertTrue(all(zipfile.is_zipfile(item) for item in first.excel_files))

            second = run_batch(files, output, config)
            self.assertEqual(second.files_skipped, 2)
            self.assertEqual(second.rows, 10)


if __name__ == "__main__":
    unittest.main()
