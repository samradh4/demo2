#!/usr/bin/env python3
"""One-click folder batch GUI for the fast voter-list OCR engine."""

from __future__ import annotations

import multiprocessing
import os
import queue
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from typing import Optional

from fast_batch_ocr import (
    BatchConfig,
    BatchResult,
    default_workers,
    discover_files,
    request_stop,
    run_batch,
    verify_tesseract_languages,
)


class BatchOCRApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title("Fast Voter List OCR - Folder Batch")
        self.geometry("940x720")
        self.minsize(820, 650)
        self.events: queue.Queue[tuple[str, object]] = queue.Queue()
        self.worker_thread: Optional[threading.Thread] = None
        self.last_result: Optional[BatchResult] = None
        self._build_style()
        self._build_ui()
        self._check_tesseract()
        self.after(120, self._poll_events)

    def _build_style(self) -> None:
        style = ttk.Style(self)
        if "clam" in style.theme_names():
            style.theme_use("clam")
        style.configure("Title.TLabel", font=("Arial", 20, "bold"))
        style.configure("Sub.TLabel", font=("Arial", 10))
        style.configure("Section.TLabelframe.Label", font=("Arial", 11, "bold"))
        style.configure("Primary.TButton", font=("Arial", 11, "bold"), padding=(14, 10))
        style.configure("Action.TButton", padding=(10, 7))

    def _build_ui(self) -> None:
        outer = ttk.Frame(self, padding=18)
        outer.pack(fill="both", expand=True)
        ttk.Label(outer, text="Fast Voter List PDF To Excel", style="Title.TLabel").pack(anchor="w")
        ttk.Label(
            outer,
            text="Select one folder, then process PDFs/images in parallel with resume support.",
            style="Sub.TLabel",
        ).pack(anchor="w", pady=(2, 12))

        self.tesseract_status = ttk.Label(outer, text="Checking Tesseract...")
        self.tesseract_status.pack(anchor="w", pady=(0, 10))

        paths = ttk.Labelframe(outer, text="1. Folders", style="Section.TLabelframe", padding=12)
        paths.pack(fill="x")
        self.input_var = tk.StringVar()
        self.output_var = tk.StringVar(value=str(Path.home() / "Desktop" / "Voter_OCR_Output"))
        self.file_count_var = tk.StringVar(value="No folder selected")

        ttk.Label(paths, text="Input folder").grid(row=0, column=0, sticky="w", pady=6)
        ttk.Entry(paths, textvariable=self.input_var).grid(row=0, column=1, sticky="ew", padx=10, pady=6)
        ttk.Button(paths, text="Choose", command=self._choose_input, style="Action.TButton").grid(row=0, column=2, pady=6)
        ttk.Label(paths, text="Output folder").grid(row=1, column=0, sticky="w", pady=6)
        ttk.Entry(paths, textvariable=self.output_var).grid(row=1, column=1, sticky="ew", padx=10, pady=6)
        ttk.Button(paths, text="Choose", command=self._choose_output, style="Action.TButton").grid(row=1, column=2, pady=6)
        ttk.Label(paths, textvariable=self.file_count_var).grid(row=2, column=1, sticky="w", padx=10, pady=(2, 0))
        paths.columnconfigure(1, weight=1)

        options = ttk.Labelframe(outer, text="2. Speed and OCR settings", style="Section.TLabelframe", padding=12)
        options.pack(fill="x", pady=(14, 0))
        self.mode_var = tk.StringVar(value="Fast")
        self.workers_var = tk.IntVar(value=default_workers())
        self.recursive_var = tk.BooleanVar(value=True)
        self.resume_var = tk.BooleanVar(value=True)
        self.skip_pages_var = tk.IntVar(value=0)
        self.limit_pages_var = tk.BooleanVar(value=False)
        self.max_pages_var = tk.IntVar(value=2)
        self.csv_var = tk.BooleanVar(value=True)

        ttk.Label(options, text="Mode").grid(row=0, column=0, sticky="w", pady=6)
        ttk.Combobox(options, textvariable=self.mode_var, values=["Fast", "Balanced", "Accurate"], state="readonly").grid(
            row=0, column=1, sticky="ew", padx=(10, 24), pady=6
        )
        ttk.Label(options, text="Parallel workers").grid(row=0, column=2, sticky="w", pady=6)
        ttk.Spinbox(options, from_=1, to=8, textvariable=self.workers_var, width=8).grid(row=0, column=3, sticky="w", padx=10, pady=6)

        ttk.Label(options, text="Skip first pages").grid(row=1, column=0, sticky="w", pady=6)
        ttk.Spinbox(options, from_=0, to=100, textvariable=self.skip_pages_var).grid(row=1, column=1, sticky="ew", padx=(10, 24), pady=6)
        self.max_pages_spin = ttk.Spinbox(options, from_=1, to=1000, textvariable=self.max_pages_var, state="disabled")
        ttk.Checkbutton(options, text="Test only first N pages", variable=self.limit_pages_var, command=self._toggle_limit).grid(
            row=1, column=2, sticky="w", pady=6
        )
        self.max_pages_spin.grid(row=1, column=3, sticky="ew", padx=10, pady=6)

        ttk.Checkbutton(options, text="Include subfolders", variable=self.recursive_var, command=self._refresh_count).grid(
            row=2, column=0, sticky="w", pady=6
        )
        ttk.Checkbutton(options, text="Resume completed files", variable=self.resume_var).grid(row=2, column=1, sticky="w", padx=10, pady=6)
        ttk.Checkbutton(options, text="Also create CSV", variable=self.csv_var).grid(row=2, column=2, sticky="w", pady=6)
        ttk.Label(options, text="Fast mode is the best starting point for thousands of files.").grid(
            row=3, column=0, columnspan=4, sticky="w", pady=(6, 0)
        )
        options.columnconfigure(1, weight=1)
        options.columnconfigure(3, weight=1)

        progress_frame = ttk.Labelframe(outer, text="3. Progress", style="Section.TLabelframe", padding=12)
        progress_frame.pack(fill="both", expand=True, pady=(14, 0))
        self.progress = ttk.Progressbar(progress_frame, maximum=100, mode="determinate")
        self.progress.pack(fill="x")
        self.status_var = tk.StringVar(value="Ready")
        ttk.Label(progress_frame, textvariable=self.status_var).pack(anchor="w", pady=(8, 8))
        self.log = tk.Text(progress_frame, height=10, wrap="word", state="disabled")
        self.log.pack(fill="both", expand=True)

        actions = ttk.Frame(outer)
        actions.pack(fill="x", pady=(14, 0))
        self.start_button = ttk.Button(actions, text="Start One-Click Batch", command=self._start, style="Primary.TButton")
        self.start_button.pack(side="left", fill="x", expand=True)
        self.stop_button = ttk.Button(actions, text="Stop Safely", command=self._stop, state="disabled", style="Action.TButton")
        self.stop_button.pack(side="left", padx=10)
        self.open_button = ttk.Button(actions, text="Open Output", command=self._open_output, state="disabled", style="Action.TButton")
        self.open_button.pack(side="left")

    def _toggle_limit(self) -> None:
        self.max_pages_spin.configure(state="normal" if self.limit_pages_var.get() else "disabled")

    def _check_tesseract(self) -> None:
        ok, message = verify_tesseract_languages("hin+eng")
        if ok:
            self.tesseract_status.configure(text=f"Tesseract ready: {message}", foreground="#1b6e1b")
            self.start_button.configure(state="normal")
        else:
            self.tesseract_status.configure(text=message, foreground="#a40000")
            self.start_button.configure(state="disabled")

    def _choose_input(self) -> None:
        selected = filedialog.askdirectory(title="Choose folder containing voter-list PDFs")
        if selected:
            self.input_var.set(selected)
            self._refresh_count()

    def _choose_output(self) -> None:
        selected = filedialog.askdirectory(title="Choose output folder")
        if selected:
            self.output_var.set(selected)

    def _refresh_count(self) -> None:
        path = Path(self.input_var.get().strip()).expanduser()
        files = discover_files(path, recursive=self.recursive_var.get()) if path.exists() else []
        self.file_count_var.set(f"{len(files)} supported file(s) found")

    def _mode_config(self) -> tuple[int, int, int, int]:
        mode = self.mode_var.get()
        if mode == "Accurate":
            return 250, 6, 120, 6
        if mode == "Balanced":
            return 200, 11, 90, 4
        return 160, 11, 60, 2

    def _validate(self) -> tuple[list[Path], Path, BatchConfig] | None:
        input_path = Path(self.input_var.get().strip()).expanduser()
        output_path = Path(self.output_var.get().strip()).expanduser()
        if not input_path.is_dir():
            messagebox.showwarning("Input folder", "Choose a valid input folder first.")
            return None
        files = discover_files(input_path, recursive=self.recursive_var.get())
        if not files:
            messagebox.showwarning("No files", "No supported PDF or image files were found in that folder.")
            return None
        try:
            output_path.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            messagebox.showerror("Output folder", f"Cannot create output folder:\n{exc}")
            return None
        dpi, psm, timeout, fallback = self._mode_config()
        config = BatchConfig(
            dpi=dpi,
            page_psm=psm,
            workers=max(1, min(8, int(self.workers_var.get()))),
            recursive=self.recursive_var.get(),
            resume=self.resume_var.get(),
            skip_first_pages=max(0, int(self.skip_pages_var.get())),
            max_pages=max(1, int(self.max_pages_var.get())) if self.limit_pages_var.get() else None,
            ocr_timeout_seconds=timeout,
            fallback_cards_per_page=fallback,
            write_csv=self.csv_var.get(),
        )
        return files, output_path, config

    def _start(self) -> None:
        validated = self._validate()
        if validated is None:
            return
        files, output, config = validated
        self.last_result = None
        self.start_button.configure(state="disabled")
        self.stop_button.configure(state="normal")
        self.open_button.configure(state="disabled")
        self.progress["value"] = 0
        self.status_var.set(f"Starting {len(files)} file(s)...")
        self._append_log(f"Starting batch with {config.workers} worker(s), {config.dpi} DPI.")
        self.worker_thread = threading.Thread(target=self._run_worker, args=(files, output, config), daemon=True)
        self.worker_thread.start()

    def _run_worker(self, files: list[Path], output: Path, config: BatchConfig) -> None:
        def progress(done: int, total: int, message: str) -> None:
            self.events.put(("progress", (done, total, message)))
        try:
            result = run_batch(files, output, config, progress)
            self.events.put(("done", result))
        except Exception as exc:
            self.events.put(("error", exc))

    def _stop(self) -> None:
        output = Path(self.output_var.get().strip()).expanduser()
        request_stop(output)
        self.stop_button.configure(state="disabled")
        self.status_var.set("Stopping safely after active pages finish...")
        self._append_log("Stop requested. Completed files remain cached for resume.")

    def _poll_events(self) -> None:
        try:
            while True:
                event, payload = self.events.get_nowait()
                if event == "progress":
                    done, total, message = payload  # type: ignore[misc]
                    self.progress["value"] = (float(done) / max(1, int(total))) * 100
                    self.status_var.set(str(message))
                    self._append_log(str(message))
                elif event == "done":
                    result: BatchResult = payload  # type: ignore[assignment]
                    self.last_result = result
                    self.start_button.configure(state="normal")
                    self.stop_button.configure(state="disabled")
                    self.open_button.configure(state="normal")
                    if result.cancelled:
                        self.status_var.set("Stopped safely. Run again with Resume enabled to continue.")
                        self._append_log("Batch stopped safely.")
                    else:
                        self.progress["value"] = 100
                        self.status_var.set(
                            f"Finished: {result.files_completed}/{result.files_total} files, {result.rows} rows, {result.files_failed} failed."
                        )
                        self._append_log(f"Excel files created: {len(result.excel_files)}")
                        messagebox.showinfo(
                            "Batch complete",
                            f"Output: {result.output_dir}\n\nFiles completed: {result.files_completed}/{result.files_total}"
                            f"\nRows: {result.rows}\nReview rows: {result.review_rows}\nFailed files: {result.files_failed}",
                        )
                elif event == "error":
                    self.start_button.configure(state="normal")
                    self.stop_button.configure(state="disabled")
                    self.status_var.set("Batch failed")
                    self._append_log(f"ERROR: {payload}")
                    messagebox.showerror("Batch failed", str(payload))
        except queue.Empty:
            pass
        self.after(120, self._poll_events)

    def _append_log(self, text: str) -> None:
        self.log.configure(state="normal")
        self.log.insert("end", text + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    def _open_output(self) -> None:
        folder = Path(self.last_result.output_dir if self.last_result else self.output_var.get()).expanduser()
        try:
            if sys.platform == "darwin":
                subprocess.Popen(["open", str(folder)])
            elif os.name == "nt":
                os.startfile(str(folder))  # type: ignore[attr-defined]
            else:
                subprocess.Popen(["xdg-open", str(folder)])
        except OSError as exc:
            messagebox.showerror("Open output", str(exc))


def main() -> int:
    multiprocessing.freeze_support()
    app = BatchOCRApp()
    app.mainloop()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
